<?php

require_once('config.php');

$filter=[];
$options=[];

$query=new MongoDB\Driver\Query($filter,$options);

$cursor=$manager->executeQuery('saneshdb.sanesh',$query);

echo json_encode($cursor->toArray()); 


?>