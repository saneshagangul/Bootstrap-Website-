<?php
  require_once('config.php');
  $fname= '';
  $lname = '';
  $Address= '';
  $Cno = 0;
  $email = '';
  $pwd='';
  $Cpwd='';
  if(isset($_POST['submit'])){
    $fname = $_POST['fname'];
    $lname= $_POST['lname'];
    $Address = $_POST['Address'];
    $Cno= $_POST['Cno'];
$email= $_POST['email'];
$pwd= $_POST['pwd'];
$Cpwd= $_POST['Cpwd'];
if(!$fname|| !$lname || !$Address || !$Cno || !$email || !$pwd || !$Cpwd ){
      }else{
          $insRec       = new MongoDB\Driver\BulkWrite;
          $insRec->insert(['fname' =>$fname, 'lname'=>$lname, 'Address'=>$Address, 'Cno'=>$Cno, 'email'=>$email,'pwd'=>$pwd,'Cpwd'=>$Cpwd]);
      
          $result= $manager->executeBulkWrite('saneshdb.sanesh', $insRec);

}
  }
