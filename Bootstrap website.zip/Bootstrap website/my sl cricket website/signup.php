<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <style>
    /* Remove the navbar's default margin-bottom and rounded borders */ 
    .navbar {
      margin-bottom: 0;
      border-radius: 0;
    }
    
    /* Set height of the grid so .sidenav can be 100% (adjust as needed) */
    .row.content {height: 450px}
    
    /* Set gray background color and 100% height */
    .sidenav {
      padding-top: 20px;
      background-color: #f1f1f1;
      height: 100%;
    }
    
    /* Set black background color, white text and some padding */
    footer {
      background-color: #555;
      color: white;
      padding: 15px;
    }
    
    /* On small screens, set height to 'auto' for sidenav and grid */
    @media screen and (max-width: 767px) {
      .sidenav {
        height: auto;
        padding: 15px;
      }
      .row.content {height:auto;} 
    }
  </style>
  <script>

	
	
	
</script>
  
  
</head>
<body>

<div class="has-bg-img">
  <img class="img-responsive" src="slteam.jpg" alt="slteam" width="100%" >
</div>




<div class="container-fluid && bg-warning">
   <div class="page-header">
    <h1 align="center ">SRI LANKA CRICKET</h1> 
    </div>     
  </div>



<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="index.html">SL Cricket Home</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li><a href="page2.html">SL CRICKET Information</a></li>
        
      </ul>
        <form class="navbar-form navbar-left" action="/action_page.php">
      <div class="input-group">
        <input type="text" class="form-control" placeholder="Search" name="search">
        <div class="input-group-btn">
          <button class="btn btn-default" type="submit">
            <i class="glyphicon glyphicon-search"></i>
          </button>
        </div>
      </div>
    </form>
        
      <ul class="nav navbar-nav navbar-right">
        <li><a href="signup.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
        <li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
      </ul>
    </div>
  </div>
</nav>
  
<div class="container-fluid text-center">    
  <div class="row content">
<div class="col-sm-2 sidenav">
      


    </div>
    <div class="col-sm-8 text-left"> 
 <div class="container">
  <h2>SIGN UP</h2>
  <form action="read.php" method="post">
    <div class="form-group col-md-9">
      <label for="fname">FirstName:</label>
      <input type='text' class="form-control" id="fname" placeholder="Enter First Name" name='fname'>
    </div><br><br>
    <div class="form-group col-md-9">
      <label for="lname">LastName:</label>
      <input type='text' class="form-control" id="lname" placeholder="Enter Last Name" name='lname'>
    </div><br><br>
    
    <div class="form-group col-md-9">
      <label for="Address">Address:</label>
      <input type='textarea' class="form-control" rows="5" id="Address" name='Address'></textarea>
    </div><br><br>
    
    <div class="form-group col-md-9">
      <label for="Cno">ContactNo:</label>
      <input type='text' class="form-control" id="Cno" placeholder="Enter Contact No" name='Cno'>
    </div><br><br>
    
    <div class="form-group col-md-9">
      <label for="email">Email:</label>
      <input type='text' class="form-control" id="email" placeholder="Enter email" name='email'>
    </div><br><br>
    
    <div class="form-group col-md-9">
      <label for="pwd">Password:</label>
      <input type='password' class="form-control" id="pwd" placeholder="Enter password" name='pwd'>
    </div><br><br>
    
    <div class="form-group col-md-9">
      <label for="Cpwd">ConfirmPassword:</label>
      <input type='password' class="form-control" id="Cpwd" placeholder="Enter Confirm password" name='Cpwd'>
    </div><br><br>
    
    
    <div class="checkbox">
      <label><input type="checkbox" name="remember"> Remember me</label>
    </div>
    <button type='submit' class="btn btn-success" name='submit'>Sign In</button><br><br>
    <button type="Reset" class="btn btn-danger">Reset</button>
  </form>
</div>

    </div>
    <div class="col-sm-2 sidenav col-md-2">
      
    </div>
  </div>
</div>

<footer class="container-fluid text-center && bg-warning">
		<div class="row">
			<div class="span3 ">

				
				<div class="text-warning">
				<h5>SANESH</h5>
				<p>SLIIT ACADEMY</p>
				<p>IT19084428</p>
				</div>
		  </div>
			
			<div class="span3 && align= center-block">
<h5>SOCIAL MEDIA </h5>
				<a href="www.facebook.com"> <img width="60" height="60" src="facebook.png" title="facebook" alt="facebook"/> </a>
				<a href="www.twitter.com"> <img width="60" height="60" src="twitter.png" title="twitter" alt="twitter"/></a>
				<a href="www.youtube.com"> <img width="60" height="60" src="youtube.png" title="youtube" alt="youtube"/></a>
		
		  </div>
</div>
<a href="#" id="back-to-top" title="Back to top" class="btn btn-primary btn-lg active icon-bar" dir="ltr">&uarr;</a></footer>

</body>
</html>