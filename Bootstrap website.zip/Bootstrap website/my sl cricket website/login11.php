<?php
if(isset($_POST['email']) && isset($_POST['pwd'])){
    $email = ($_POST['email']);
    $pwd = ($_POST['pwd']);
    $pass_hash = md5($pwd );
    if(empty( $email)){
        die("Empty or invalid email address");
    }
    if(empty($pwd )){
        die("Enter your password");
    }
    $con = new MongoClient();
    // Select Database
    if($con){
        $db = $con->saneshdb;
        // Select Collection
        $collection = $db->sanesh;   
        $qry = array("email" =>  $email, "pwd" => $pass_hash);
        $result = $collection->findOne($qry);

        if(!empty($result)){
            echo "You are successfully loggedIn";
        }else{
            echo "Wrong combination of username and password";
        }
    }else{
        die("Mongo DB not connected!");
    }
}
?>


